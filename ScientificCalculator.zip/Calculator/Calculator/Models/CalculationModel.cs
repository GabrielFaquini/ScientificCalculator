using System;

namespace Calculator.Models
{
    public class CalculationModel
    {
        public string Operation { get; set; }

        public string FirstNumber { get; set; }

        public string SecondNumber { get; set; }
    }
}
